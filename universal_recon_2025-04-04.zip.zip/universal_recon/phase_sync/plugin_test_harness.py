import sys
import os
import json

# === Path Setup ===
script_dir = os.path.dirname(os.path.abspath(__file__))
universal_recon_dir = os.path.abspath(os.path.join(script_dir, '..'))

# Add core/, validators/, and analytics/ to sys.path
for folder in ['core', 'validators', 'analytics']:
    path_to_add = os.path.join(universal_recon_dir, folder)
    if path_to_add not in sys.path:
        sys.path.insert(0, path_to_add)
        print(f"[DEBUG] Added to sys.path: {path_to_add}")

# Also add universal_recon itself so relative imports work
if universal_recon_dir not in sys.path:
    sys.path.insert(0, universal_recon_dir)
    print(f"[DEBUG] Added universal_recon_dir to sys.path: {universal_recon_dir}")

# === Plugin Imports ===
try:
    from plugin_loader import load_plugins
    from report_printer import print_full_report
except ImportError as e:
    print(f"Import error: {e}")
    sys.exit(1)

def main():
    print("=== PHASE 14B: PLUGIN TEST HARNESS ===")

    registry_path = os.path.join(universal_recon_dir, 'plugin_registry.json')
    print(f"[DEBUG] registry_path = {registry_path}")

    if not os.path.exists(registry_path):
        print(f"❌ plugin_registry.json not found at {registry_path}")
        return

    plugins = load_plugins(registry_path=registry_path, plugin_type=None)
    print(f"Loaded {len(plugins)} plugin(s):")
    for (name, mod) in plugins:
        print(f" - {name} => {mod}")

    for (name, mod) in plugins:
        if hasattr(mod, 'run_analysis'):
            try:
                print(f"\n[Plugin: {name}] -> run_analysis()")
                result = mod.run_analysis()
                print(f"Analysis result: {result}")
            except Exception as e:
                print(f"Error in {name}: {e}")
        elif hasattr(mod, 'validate'):
            try:
                print(f"\n[Plugin: {name}] -> validate()")
                sample = {"field": "test_value"}
                result = mod.validate(sample)
                print(f"Validation result: {result}")
            except Exception as e:
                print(f"Error in {name}: {e}")
        else:
            print(f"\n[Plugin: {name}] No valid entry point.")

    site_name = "test_site"
    print("\n=== Attempting to load & print full report ===")
    print_full_report(site_name)
    print("\n=== Test Harness Completed ===")

if __name__ == "__main__":
    main()
