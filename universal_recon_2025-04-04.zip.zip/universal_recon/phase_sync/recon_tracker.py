import os
import sys
import importlib
import traceback
from datetime import datetime

# Project root setup
PHASE_PATH = os.path.dirname(os.path.abspath(__file__))
RECON_PATH = os.path.abspath(os.path.join(PHASE_PATH, ".."))
sys.path.extend([
    RECON_PATH,
    os.path.join(RECON_PATH, "core"),
    os.path.join(RECON_PATH, "validators"),
    os.path.join(RECON_PATH, "analytics")
])

PLUGIN_REGISTRY_PATH = os.path.join(RECON_PATH, "plugin_registry.json")
LOG_PATH = os.path.join(PHASE_PATH, "plugin_tracker_log.txt")

# Load plugin registry
import json
with open(PLUGIN_REGISTRY_PATH, "r", encoding="utf-8") as f:
    plugin_config = json.load(f)

summary = []
failures = []

def log(msg):
    print(msg)
    with open(LOG_PATH, "a", encoding="utf-8") as log_file:
        log_file.write(msg + "\n")

def load_and_test_plugin(module_path, plugin_name):
    try:
        mod = importlib.import_module(module_path)
        if hasattr(mod, "validate"):
            result = mod.validate({"field": "sample"})
        elif hasattr(mod, "run_analysis"):
            result = mod.run_analysis()
        else:
            result = "⚠️ No entry point found"
        summary.append((plugin_name, "✅ Loaded", result))
    except Exception as e:
        tb = traceback.format_exc()
        failures.append((plugin_name, "❌ Error", str(e)))
        log(f"\n[ERROR] {plugin_name} failed:\n{tb}")

def run_tracker():
    log("\n==== Recon Plugin Tracker Started: {} ====\n".format(datetime.now()))
    for plugin in plugin_config:
        if not isinstance(plugin, dict):
            continue
        name = plugin.get("name")
        module_path = plugin.get("module")
        if plugin.get("enabled", True):
            load_and_test_plugin(module_path, name)
    log("\n==== Summary ====")
    for entry in summary:
        log(f"{entry[0]} | {entry[1]}")
    for entry in failures:
        log(f"{entry[0]} | {entry[1]} | {entry[2]}")
    log("\n==== End ====\n")

if __name__ == "__main__":
    run_tracker()
