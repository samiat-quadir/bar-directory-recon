import os
import json


def save_summary(site_name: str, summary: dict):
    os.makedirs("output/reports", exist_ok=True)
    path = os.path.join("output/reports", f"{site_name}_summary.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"[INFO]  Summary saved to {path}")


def save_audit(site_name: str, audit_data: dict):
    os.makedirs("output/reports", exist_ok=True)
    path = os.path.join("output/reports", f"{site_name}_audit.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(audit_data, f, indent=2)
    print(f"[INFO]  Audit saved to {path}")


def save_trend(site_name: str, trend_data: dict):
    os.makedirs("output/reports", exist_ok=True)
    path = os.path.join("output/reports", f"{site_name}_trend.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(trend_data, f, indent=2)
    print(f"[INFO]  Trend saved to {path}")


def save_heatmap(site_name: str, heatmap_data: dict):
    os.makedirs("output/reports", exist_ok=True)
    path = os.path.join("output/reports", f"{site_name}_heatmap.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(heatmap_data, f, indent=2)
    print(f"[INFO]  Heatmap saved to {path}")


def save_full_report(site_name: str, full_report: dict):
    os.makedirs("output/reports", exist_ok=True)
    path = os.path.join("output/reports", f"{site_name}_full_report.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(full_report, f, indent=2)
    print(f"[INFO]  Full report saved to {path}")
