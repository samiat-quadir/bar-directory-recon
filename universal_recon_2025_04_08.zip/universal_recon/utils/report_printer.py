# utils/report_printer.py

def print_report(site_name=None, summary=None, audit=None, trend=None, health=None, heatmap=None, full=None, verbose=False):
    print("\n Recon Summary Report")
    if summary:
        print(f"Total Records: {summary.get('total_records')}")
        print(f"Valid Count: {summary.get('valid_count')}")
        print(f"Invalid Count: {summary.get('invalid_count')}")
        if verbose:
            print("Top Fields:")
            for field, count in summary.get("top_fields", {}).items():
                print(f"  - {field}: {count}")

    print("\n Audit Summary")
    if audit:
        for key, value in audit.items():
            print(f"  {key}: {value}")

    print("\n Trend Analysis")
    if trend:
        print(f"  Score Trend: {trend.get('trend')}")

    print("\n Health Flags")
    if health:
        for key, value in health.items():
            print(f"  {key}: {value}")

    if full:
        print("\n Full Report (Summary)")
        for key in full:
            print(f"  {key}: [present]")
