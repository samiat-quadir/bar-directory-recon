import json
import sys
import os
import traceback

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.plugin_loader import load_plugins_by_type
from core.retry import retry

# Mock data
MOCK_RECORDS = [
    {"type": "name", "value": "Jane Doe", "score": 5, "rank": 1},
    {"type": "email", "value": "jane@example.com", "score": 3, "rank": 2},
    {"type": "bar_number", "value": "123456", "score": 2},
    {"type": "firm_name", "value": "Example LLP", "score": 4}
]

def main():
    config = {
        "site": "test_site",
        "mode": "full"
    }

    print("\n=== Running Plugin Test Harness (Phase 14c) ===")
    plugins = load_plugins_by_type("analytics") + load_plugins_by_type("validator")

    for mod in plugins:
        name = mod.__name__.split(".")[-1]

        try:
            if hasattr(mod, "run_analysis"):
                print(f" [Analytics] {name}")
                results = retry()(mod.run_analysis)(MOCK_RECORDS, config)
                print("  ✔ Output keys:", list(results.keys())[:5], "\n")

            elif hasattr(mod, "validate_records"):
                print(f"  [Validator] {name}")
                validated = retry()(mod.validate_records)(MOCK_RECORDS, strict=False, verbose=False)
                print(f"  ✔ Validated: {len(validated)} records\n")

            else:
                print(f"  Unknown plugin type: {name}")

        except Exception as e:
            print(f"  Error in {name}: {e}")
            traceback.print_exc()
            continue

if __name__ == "__main__":
    main()
