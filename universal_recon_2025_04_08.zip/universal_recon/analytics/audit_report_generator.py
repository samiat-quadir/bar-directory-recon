from typing import List, Dict
from collections import Counter

def run_analysis(records: List[Dict], config: Dict = None) -> Dict:
    """
    Analyzes validation results across records and summarizes errors by severity and plugin.
    """

    summary = {
        "plugin": "audit_score_matrix_generator",
        "total_records": len(records),
        "severity_counts": Counter(),
        "plugin_errors": {},  # plugin -> count
        "field_errors": {},   # field -> count
    }

    for record in records:
        if not record.get("valid", True):
            severity = record.get("severity", "unknown")
            plugin = record.get("plugin", "unknown_plugin")
            field = record.get("type", "unknown_field")

            summary["severity_counts"][severity] += 1

            # Plugin error count
            if plugin not in summary["plugin_errors"]:
                summary["plugin_errors"][plugin] = 0
            summary["plugin_errors"][plugin] += 1

            # Field error count
            if field not in summary["field_errors"]:
                summary["field_errors"][field] = 0
            summary["field_errors"][field] += 1

    return dict(summary)
