import os
from typing import List, Dict

# Core analytics functions
from utils import recon_summary_builder
from utils import score_visualizer
from utils import recon_trend_tracker

# Plugin-style analytics with run_analysis interfaces
from analytics.audit_report_generator import run_analysis as run_audit
from analytics.template_health_flagger import run_analysis as run_health
from analytics.full_report_generator import run_analysis as run_full_report

# Output and CLI utilities
from utils.output_manager import (
    save_summary,
    save_audit,
    save_heatmap,        # ✅ correct function name
    save_trend,
    save_full_report
)

from utils.report_printer import print_report


def aggregate_and_print(
    records: List[Dict],
    site_name: str,
    config: Dict,
    cli_flags: Dict,
):
    """Run all analytics plugins, save results, print final report."""

    summary_data = recon_summary_builder.run_analysis(records, config)
    audit_data = run_audit(records, config)
    trend_data = recon_trend_tracker.run_analysis(records, config)
    heatmap_data = score_visualizer.generate_heatmap_data(records)
    health_data = run_health(records, config)

    # Save individual JSON reports
    save_summary(site_name, summary_data)
    save_audit(site_name, audit_data)
    save_trend(site_name, trend_data)
    save_heatmap(site_name, heatmap_data)

    # Compose full report if requested
    full_report = {}
    if cli_flags.get("full_report", False):
        full_report = run_full_report(
            summary=summary_data,
            audit=audit_data,
            trend=trend_data,
            health=health_data,
        )
        save_full_report(site_name, full_report)

    # Trigger CLI summary print
    print_report(
        site_name=site_name,
        summary=summary_data,
        audit=audit_data,
        trend=trend_data,
        health=health_data,
        heatmap=heatmap_data,
        full=full_report if cli_flags.get("full_report") else None,
        verbose=cli_flags.get("verbose", False),
    )
